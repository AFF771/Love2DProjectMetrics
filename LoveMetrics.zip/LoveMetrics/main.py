# Made by AFF771

import os

def read_lua_files(lua_folder):
    lua_files = [file for file in os.listdir(lua_folder) if file.endswith('.lua')]
    if len(lua_files) == 0:
        return False, 0, 0, 0
    lineCount = 0
    commentCount =  0
    functionCount =  0
    for lua_file in lua_files:
        with open(os.path.join(lua_folder, lua_file), 'r') as file:
            comment = False
            for line in file:
                if "--" in line or "[[" in line or "]]" in line:
                    if "[[" in line:
                        comment = True
                    elif "]]" in line:
                        comment = False
                    commentCount += 1
                elif comment==True:
                    commentCount += 1
                elif line.strip() != '' and line != '':
                    if "function" in line:
                        functionCount += 1
                    lineCount += 1
    
    return True, str(lineCount), str(commentCount), str(functionCount)

if __name__ == "__main__":
    lua_folder = "code_files"
    success, lines, comments, functions = read_lua_files(lua_folder)
    if not success :
        print("\n\nNo '.lua' files found inside fodler.")
        print("USAGE: copy '.lua' files from your LOVE2D project into 'code_files' folder and run 'run.bat'.\n")
    else:
        print("\n\n----- LOVE2D PROJECT SPECS -----")
        print (lines + " lines of code")
        print (comments + " lines of comments")
        print(functions + " functions")
        print("--------------------------------" + "\n")